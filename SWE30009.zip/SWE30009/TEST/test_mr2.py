import sys
import os
from test_cases_mr2 import test_cases

original_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../SUT'))
sys.path.insert(0, original_dir)

from merge_sort import merge_sort

def test_mr_concatenation():
    mr_outputs = []
    expected_outputs = []

    for first_list, second_list in test_cases:
        concatenated_list = first_list + second_list
        sorted_concatenated = merge_sort(concatenated_list)

        sorted_first = merge_sort(first_list)
        sorted_second = merge_sort(second_list)

        expected_output = merge_sort(sorted_first + sorted_second)

        mr_output = (f"MR succeeded for SI={first_list} and {second_list}, "
                     f"SO={sorted_concatenated}, FI={sorted_first + sorted_second}")
        
        expected_message = f"Expected FO={expected_output}"

        mr_outputs.append(mr_output)
        expected_outputs.append(expected_message)

        assert sorted_concatenated == expected_output, \
            f"Failed MR for first_list={first_list} and second_list={second_list}. " \
            f"Expected: {expected_output}, Got: {sorted_concatenated}"

    print("\n".join(mr_outputs))
    print("\n".join(expected_outputs))

if __name__ == "__main__":
    test_mr_concatenation()
