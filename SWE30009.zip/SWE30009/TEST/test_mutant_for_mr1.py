import sys
import os
import importlib
from tabulate import tabulate
from test_cases_mr1 import test_cases

# Setting up paths
base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../SUT'))
sys.path.insert(0, base_dir)

from merge_sort import merge_sort

mutant_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../MUTANTS'))
sys.path.insert(0, mutant_path)

def load_mutant(mutant_identifier):
    mutant_module = importlib.import_module(mutant_identifier)
    return mutant_module.merge_sort

def collect_mr_outputs():
    expected_results = []
    for primary_list, secondary_list in test_cases:
        sorted_primary = merge_sort(primary_list[:])
        sorted_secondary = merge_sort(secondary_list[:])
        expected_results.append((sorted_primary, sorted_secondary))
    return expected_results

def trim_output_list(output, limit=10):
    if len(output) > limit:
        return f"{output[:limit]} ..."
    return output

def execute_tests_on_mutants(mutant_identifiers, test_cases):
    results_summary = []

    for mutant_identifier in mutant_identifiers:
        try:
            mutant_merge_function = load_mutant(mutant_identifier)

            for primary_list, secondary_list in test_cases:
                primary_result = mutant_merge_function(primary_list[:])
                secondary_result = mutant_merge_function(secondary_list[:])
                outcome = "Survived" if primary_result == secondary_result else "Killed"
                results_summary.append([
                    mutant_identifier,
                    primary_list,
                    trim_output_list(primary_result),
                    secondary_list,
                    trim_output_list(secondary_result),
                    outcome
                ])
        except Exception as error:
            for primary_list, secondary_list in test_cases:
                results_summary.append([mutant_identifier, primary_list, "Error", secondary_list, "Error", "Killed"])

    return results_summary

if __name__ == "__main__":
    mutant_identifiers = [f"m{i}" for i in range(1, 31)]
    expected_outputs = collect_mr_outputs()
    mutant_test_results = execute_tests_on_mutants(mutant_identifiers, test_cases)
    
    table_headers = ["Mutant", "Source Input", "Source Output", "Follow-up Input", "Follow-up Output", "Result"]
    print(tabulate(mutant_test_results, table_headers, tablefmt="grid"))

    for (sorted_primary, sorted_secondary) in expected_outputs:
        print(f"Expected FO={sorted_secondary}")
