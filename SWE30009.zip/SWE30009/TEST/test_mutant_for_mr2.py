import sys
import os
import importlib
from tabulate import tabulate

# Directory paths for mutants and the original source
mutants_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../MUTANTS'))
sys.path.insert(0, mutants_path)

source_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../SUT'))
sys.path.insert(0, source_path)

from merge_sort import merge_sort

# Test cases for the sorting function
test_data = [
    ([2, 1, 3], [6, 5, 4]),
    ([8, 7], [3, 2, 1]),
    ([4, 5, 3], [2, 1]),
    ([30, 10, 20], [15, 5]),
    ([14, 12], [8, 6, 2])
]

def load_mutant(mutant_identifier):
    """Import the mutant module by its identifier."""
    mutant_module = importlib.import_module(mutant_identifier)
    return mutant_module.merge_sort

def execute_tests_on_mutants(test_data):
    results_summary = []

    for i in range(1, 31):
        mutant_identifier = f"m{i}"

        try:
            mutant_sort_function = load_mutant(mutant_identifier)

            for primary_list, secondary_list in test_data:
                try:
                    combined_list = primary_list + secondary_list
                    sorted_combined = merge_sort(combined_list)

                    sorted_primary = mutant_sort_function(primary_list)
                    sorted_secondary = mutant_sort_function(secondary_list)

                    follow_up_result = sorted_primary + sorted_secondary
                    
                    outcome = "Killed" if sorted_combined != follow_up_result else "Survived"

                    results_summary.append([mutant_identifier, primary_list, secondary_list, 
                                            sorted_combined, follow_up_result, outcome])
                
                except Exception as e:
                    results_summary.append([mutant_identifier, primary_list, secondary_list, 
                                            "Error", "Error", "Killed"])

        except Exception as e:
            for primary_list, secondary_list in test_data:
                results_summary.append([mutant_identifier, primary_list, secondary_list, 
                                        "Error", "Error", "Killed"])

    return results_summary

if __name__ == "__main__":
    all_test_results = execute_tests_on_mutants(test_data)

    table_headers = ["Mutant", "Source List 1", "Source List 2", 
                     "Sorted Combined", "Follow-up Result", "Outcome"]

    print(tabulate(all_test_results, table_headers, tablefmt="grid"))
