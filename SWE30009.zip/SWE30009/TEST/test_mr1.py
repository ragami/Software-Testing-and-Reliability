import sys
import os
from test_cases_mr1 import test_cases

original_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../SUT'))
sys.path.insert(0, original_dir)

from merge_sort import merge_sort

def retrieve_mr_outputs():
    results = []
    for input_list, subsequent_list in test_cases:
        sorted_input = merge_sort(input_list[:])
        sorted_subsequent = merge_sort(subsequent_list[:])
        results.append((sorted_input, sorted_subsequent))

    return results

def verify_reordering():
    for input_list, subsequent_list in test_cases:
        sorted_input = merge_sort(input_list[:])
        sorted_subsequent = merge_sort(subsequent_list[:])
        assert sorted_subsequent == sorted_input[:sorted_input.index(subsequent_list[-1]) + 1] + [subsequent_list[-1]] + sorted_input[sorted_input.index(subsequent_list[-1]) + 1:], \
            f"Verification failed for SI={input_list} and FI={subsequent_list}. Expected: {sorted_input[:sorted_input.index(subsequent_list[-1]) + 1] + [subsequent_list[-1]] + sorted_input[sorted_input.index(subsequent_list[-1]) + 1:]}, Got: {sorted_subsequent}"
        print(f"Verification succeeded for SI={input_list}, SO={sorted_input}, FI={subsequent_list}")

if __name__ == "__main__":
    verify_reordering()
    expected_outputs = retrieve_mr_outputs()
    for (sorted_input, sorted_subsequent) in expected_outputs:
        print(f"Expected FO={sorted_subsequent}")
