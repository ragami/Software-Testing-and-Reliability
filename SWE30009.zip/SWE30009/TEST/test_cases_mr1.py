
test_cases = [
    ([4, 1, 3, 2], [4, 1, 3, 2, 2]),  # Duplicate element (2)
    ([5, 3, 8, 5, 1], [5, 3, 8, 5, 1, 5]),  # Duplicate element (5)
    ([9, 4, 7, 9, 2], [9, 4, 7, 9, 2, 9]),  # Duplicate element (9)
    ([6, 1, 3, 2], [6, 1, 3, 2, 1]),  # Duplicate element (1)
    ([8, 3, 6, 3], [8, 3, 6, 3, 3]),  # Duplicate element (3)
]
